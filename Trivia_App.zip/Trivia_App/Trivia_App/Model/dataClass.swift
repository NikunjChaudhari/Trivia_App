//
//  dataClass.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

// make class that help to insert data in attributes of entity
class dataClass: NSObject {
    
    var question1 = ""
    var answer1 = ""
    var question2 = ""
    var answer2 = ""
    var question3 = ""
    var answer3 = ""
    var dateAndTime = ""
    
    init(question1:String,answer1:String,question2:String,answer2:String,question3:String,answer3:String,dateAndTime:String) {
        
        
        self.question1 = question1;
        self.answer1 = answer1
        self.question2 = question2;
        self.answer2 = answer2;
        self.question3 = question3;
        self.answer3 = answer3;
        self.dateAndTime = dateAndTime;
    }
}
