
import Foundation
import UIKit
import CoreData

// create viewcontext and persistenCoordinator for core data
var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
var persistanceStoreCordinator = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.persistentStoreCoordinator

// create entity to insert data in Entity of Data Model name as Trivia
var entity = NSEntityDescription.insertNewObject(forEntityName: "Trivia", into: context)
extension UIViewController{
    
    // put bottom line in textfield for good ui appear
    func setBottomLine(txt: UITextField)
    {
        let layer = CALayer()
        layer.frame = CGRect(x: 0, y: txt.frame.height - 2 , width: txt.frame.size.width, height: 2)
        txt.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        layer.borderWidth = 2
        layer.borderColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
        txt.layer.addSublayer(layer)
    }
    
    // use navigation controller for go to one page to other
    func nextPage(identifier: String){
        
        let navigate = self.storyboard?.instantiateViewController(withIdentifier: identifier)
        self.navigationController?.pushViewController(navigate!, animated: true)
    }
    func homePage()
    {
        self.navigationController?.popToViewController((self.navigationController?.viewControllers[1])!, animated: true)
    }
    func firstPage()
    {
        self.navigationController?.popToViewController((self.navigationController?.viewControllers[2])!, animated: true)
    }
    
    func prevPage()
    {
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    // popup alert on click on home button
    func homeAlert(warning:String)
    {
        let alert = UIAlertController(title: "Warning", message: warning, preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default) { (act) in
            self.homePage()
        }
        let no = UIAlertAction(title: "No", style: .default) { (act) in
            self.dismiss(animated: true, completion: nil)
        }
        alert.addAction(yes)
        alert.addAction(no)
        self.present(alert, animated: true, completion: nil)
    }
    
    // popup alert on click on finish button
    func setAlert(warning:String)
    {
        let alert = UIAlertController(title: "Warning", message: warning, preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default) { (act) in
            self.firstPage()
        }
        let no = UIAlertAction(title: "No", style: .default) { (act) in
            self.dismiss(animated: true, completion: nil)
        }
        alert.addAction(yes)
        alert.addAction(no)
        self.present(alert, animated: true, completion: nil)
    }
    
    // when click next on third question immediately return current date and time
    func currentdate() -> String
    {
        
        
        let date = Date()
        
        // first 5 lines are only for date with suffix th,nd,rd etc
        let calendar = Calendar.current
        let dateComponents = calendar.component(.day, from: date)
        let numberFormatter = NumberFormatter()
        
        numberFormatter.numberStyle = .ordinal
        
        let day = numberFormatter.string(from: dateComponents as NSNumber)
        
        // put month and time
        let frm = DateFormatter()
        frm.dateFormat = "MMM HH:mm a"
        let dateString = "\(day!) \(frm.string(from: date))"
        
        
        return dateString
    }
    
    
    // insert function to insert data in core data (data model)
    func insertData(modleObj:dataClass) -> Bool {
        
        
        var status:Bool = false;
        entity.setValue(modleObj.question1, forKey: "question1");
        entity.setValue(modleObj.question2, forKey: "question2");
        entity.setValue(modleObj.question3, forKey: "question3");
        entity.setValue(modleObj.answer1, forKey: "answer1");
        entity.setValue(modleObj.answer2, forKey: "answer2");
        entity.setValue(modleObj.answer3, forKey: "answer3");
        entity.setValue(modleObj.dateAndTime, forKey: "dateAndTime");
        
        
        do {
            try context.save()
            
            status = true;
            
            return status ;
        } catch let err as NSError {
            print("err=\(err)")
            return status;
        }
    }
    
    // method to see data from data model
    func getdata() -> [Trivia] {
        
        
        var trivia = [Trivia]()
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Trivia");
        
        do {
            trivia  = try context.fetch(request) as! [Trivia];
            return trivia
        } catch  {
        }
        return trivia;
    }
    
    // to delete whole data means empty history
    func deletedata()
    {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Trivia")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try persistanceStoreCordinator.execute(deleteRequest, with: context)
        } catch let error as NSError {
            // TODO: handle the error
        }
    }
}


// set ui for good appearance of uiview
extension UIView{
    
    func setupUI()
    {
        layer.masksToBounds = false
        layer.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: 1, height: 1)
        layer.shadowRadius = 1
        layer.cornerRadius = 15
    }
}

// set ui for good appearance of uibutton

extension UIButton{
    func setupUI(Color: CGColor) {
        layer.masksToBounds = false
        layer.shadowColor = Color
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: 1, height: 1)
        layer.shadowRadius = 1
        layer.cornerRadius = 15
        
    }
}
