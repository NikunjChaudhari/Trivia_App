//
//  HistoryCell.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class HistoryCell: UITableViewCell {
    
    @IBOutlet weak var lblGameDateTime: UILabel!
    @IBOutlet weak var lblAns1: UILabel!
    @IBOutlet weak var lblQue2: UILabel!
    @IBOutlet weak var lblAns2: UILabel!
    @IBOutlet weak var lblQue3: UILabel!
    @IBOutlet weak var lblAns3: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
