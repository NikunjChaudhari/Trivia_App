//
//  ViewController.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // make a splash screen with customise time then go to main page
    var time = Timer()
    var a = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        time = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.handle), userInfo: nil, repeats: false)
        
        // Do any additional setup after loading the view.
    }
    
    @objc func handle()
    {
        self.nextPage(identifier: "Homepage")
    }
    
    
}

