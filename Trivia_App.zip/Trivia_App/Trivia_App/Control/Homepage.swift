//
//  Homepage.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class Homepage: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func playClicked(_ sender: Any)
    {
        self.nextPage(identifier: "FirstQues")
    }
    
    @IBAction func checkHistory(_ sender: Any)
    {
        self.nextPage(identifier: "History")
    }
    @IBAction func clearHistory(_ sender: Any)
    {
        self.deletedata()
    }
    
}
