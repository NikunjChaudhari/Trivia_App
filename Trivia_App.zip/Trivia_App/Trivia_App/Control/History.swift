//
//  History.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class History: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let detailArray = arr[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell1") as! HistoryCell
        cell.lblAns1.text = "Name: \(detailArray.answer1 ?? "Name: ")"
        cell.lblQue2.text = detailArray.question2
        cell.lblQue3.text = detailArray.question3
        cell.lblAns2.text = detailArray.answer2
        cell.lblAns3.text = detailArray.answer3
        cell.lblGameDateTime.text = detailArray.dateAndTime
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    var arr = [Trivia]()
    
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnReplay: UIButton!
    
    @IBOutlet weak var tblHistory: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        arr = self.getdata()
        btnHome.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnReplay.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func replayClicked(_ sender: Any) {
        // go to first question
        self.setAlert(warning: "Are you want to replay?")
    }
    
    @IBAction func homeClicked(_ sender: Any) {
        // go to initial page
        self.homeAlert(warning: "Are you sure to  not playing more?")
    }
    
    
}
