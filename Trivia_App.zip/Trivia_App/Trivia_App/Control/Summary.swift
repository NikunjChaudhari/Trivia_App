//
//  Summary.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit
class Summary: UIViewController {
    
    var arr = [Trivia]()
    
    func setvalue()
    {
        let answer1 = UserDefaults.standard.value(forKey: "answer1") as! String
        let answer2 = UserDefaults.standard.value(forKey: "answer2") as! String
        let answer3 = UserDefaults.standard.value(forKey: "answer3") as! String
        
        lblAnswer1.text = "Name: \(answer1) "
        lblAnswer2.text = answer2
        lblAnswer3.text = answer3
    }
    @IBOutlet weak var lblAnswer1: UILabel!
    @IBOutlet weak var lblAnswer2: UILabel!
    @IBOutlet weak var lblAnswer3: UILabel!
    @IBOutlet weak var btnFinish: UIButton!
    @IBOutlet weak var btnHistory: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setvalue()
        
        
        
        btnFinish.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnHistory.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnHome.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        
        // to get data in single array
        arr = self.getdata()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func homeClicked(_ sender: Any)
    {
        // go to initial page
        self.homeAlert(warning: "Are you sure to not playing games more?")
    }
    @IBAction func finishClicked(_ sender: Any) {
        // go to first question
        self.setAlert(warning: "Are you want to replay?")
    }
    
    @IBAction func historyClicked(_ sender: Any)
    {
        // go to history
        self.nextPage(identifier: "History")
    }
    
    
}
