//
//  FirstQues.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit
import Foundation
class FirstQues: UIViewController {
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // make button and textfield  more attractive
        btnNext.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnHome.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        self.setBottomLine(txt: txtName)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func nextClick(_ sender: Any) {
        
        if txtName.text!.count > 0
        {
            
            // save data in userdefault which may use in future
            UserDefaults.standard.set(txtName.text!, forKey: "answer1")
            UserDefaults.standard.set("What is your Name?", forKey: "question1")
            
            // navigate to next page
            self.nextPage(identifier: "SecQues")
        }
        else{
            let alert = UIAlertController(title: "Warning", message: "Please type your name", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func homeClicked(_ sender: Any)
    {
        // go to home page from where user can play and or check history
        self.homeAlert(warning: "Are you sure to not playing games more?")
    }
}



extension UIViewController : UITextFieldDelegate
{
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return self.view.endEditing(true)
    }
}
