//
//  SecQues.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit

class SecQues: UIViewController {
    
    var Ans = ""
    
    @IBOutlet weak var btnOptionA: UIButton!
    @IBOutlet weak var btnOptionB: UIButton!
    @IBOutlet weak var btnOptionC: UIButton!
    @IBOutlet weak var btnOptionD: UIButton!
    
    @IBOutlet weak var lblWarning: UILabel!
    
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnPrev: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // make button more attractive
        btnNext.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnPrev.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnHome.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func selectAnswer(_ sender: UIButton)
    {
        // logic for select any one option from given option
        if sender.tag == 1
        {
            btnOptionA.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            btnOptionB.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionC.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionD.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            Ans = "Sachin Tendulkar"
            
        }
        else if sender.tag == 2
        {
            btnOptionA.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionB.backgroundColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
            btnOptionC.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionD.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            Ans = "Virat Kohli"
            
        }
        else if sender.tag == 3
        {
            btnOptionA.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionB.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionC.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
            btnOptionD.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            Ans = "Adam Gilchirst"
            
        }
        else if sender.tag == 4
        {
            btnOptionA.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionB.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionC.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
            btnOptionD.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
            Ans = "Jacques Kallis"
            
        }
    }
    @IBAction func NextClicked(_ sender: Any) {
        // save data in userdefault which may use in future
        if Ans.count > 0
        {
            UserDefaults.standard.set("Who is the best cricketer in the world?", forKey: "question2")
            UserDefaults.standard.set(Ans, forKey: "answer2")
            self.nextPage(identifier: "ThirdQues")
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "Please select option", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    @IBAction func prevClicked(_ sender: Any) {
        self.prevPage()
    }
    
    @IBAction func homeClicked(_ sender: Any)
    {
        self.homeAlert(warning: "Are you sure to not playing games more?")    }
}
