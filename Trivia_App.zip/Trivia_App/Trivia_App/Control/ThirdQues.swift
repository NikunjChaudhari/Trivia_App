//
//  ThirdQues.swift
//  Trivia_App
//
//  Created by macos on 22/07/20.
//  Copyright © 2020 macos. All rights reserved.
//

import UIKit
import CoreData
class ThirdQues: UIViewController {
    
    // put different flag in each button to do event like select and deselect
    var flag1 = 0
    var flag2 = 0
    var flag3 = 0
    var flag4 = 0
    
    var ansArray = [String]()
    var finalArray = [Trivia]()
    
    
    @IBOutlet weak var btnOptionA: UIButton!
    @IBOutlet weak var btnOptionB: UIButton!
    @IBOutlet weak var btnOptionC: UIButton!
    @IBOutlet weak var btnOptionD: UIButton!
    @IBOutlet weak var lblWarning: UILabel!
    
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnPrev: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // for make button more attractive
        btnNext.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnPrev.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        btnHome.setupUI(Color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func selectAnswer(_ sender: UIButton)
    {
        // logic for select multiple option
        if sender.tag == 1
        {
            if flag1 == 0
            {
                btnOptionA.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
                flag1 = 1
                ansArray.append("White")
            }
            else
            {
                btnOptionA.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
                flag1 = 0
                ansArray.removeLast()
            }
        }
        else if sender.tag == 2
        {
            if flag2 == 0
            {
                btnOptionB.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
                flag2 = 1
                ansArray.append("Yellow")
            }
            else
            {
                btnOptionB.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
                flag2 = 0
                ansArray.removeLast()
            }
        }
        else if sender.tag == 3
        {
            if flag3 == 0
            {
                btnOptionC.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
                flag3 = 1
                ansArray.append("Orange")
            }
            else
            {
                btnOptionC.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
                flag3 = 0
                ansArray.removeLast()
            }
        }
        else if sender.tag == 4
        {
            if flag4 == 0
            {
                btnOptionD.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
                flag4 = 1
                ansArray.append("Green")
            }
            else
            {
                btnOptionD.backgroundColor = #colorLiteral(red: 0.4156862745, green: 0.1725490196, blue: 0.4392156863, alpha: 1)
                flag4 = 0
                ansArray.removeLast()
            }
        }
    }
    @IBAction func nextClicked(_ sender: Any)
    {
        
        
        // make separated comma after each value we get from answer 3
        var answerStr = ""
        for item in ansArray
        {
            answerStr.append(item)
            answerStr.appending(", ")
        }
        print(answerStr)
        if answerStr.count > 0
        {
            // set userdefault for further use
            UserDefaults.standard.set("What are the colors in the Indian national flag?", forKey: "question3")
            UserDefaults.standard.set(answerStr, forKey: "answer3")
            UserDefaults.standard.set(self.currentdate(), forKey: "dateAndTime")
            
            // get value from each unique key with a purpose of put in data model
            let question1 = UserDefaults.standard.value(forKey: "question1") as! String
            let question2 = UserDefaults.standard.value(forKey: "question2") as! String
            let answer1 = UserDefaults.standard.value(forKey: "answer1") as! String
            let answer2 = UserDefaults.standard.value(forKey: "answer2") as! String
            let dateAndTime = UserDefaults.standard.value(forKey: "dateAndTime") as! String
            let question3 = UserDefaults.standard.value(forKey: "question3") as! String
            let answer3 = UserDefaults.standard.value(forKey: "answer3") as! String
            
            // insert all value in variables accordingly
            let dc = dataClass(question1: question1, answer1: answer1, question2: question2, answer2: answer2, question3: question3, answer3: answer3, dateAndTime: dateAndTime)
            
            // call insertdata function which give us true or false value
            let status = self.insertData(modleObj: dc)
            if status == true
            {
                print("data inserted")
            }
            else
            {
                print("not inserted")
            }
            
            self.nextPage(identifier: "Summary")
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "Please select option", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
    
    @IBAction func prevClicked(_ sender: Any)
    {
        self.prevPage()
        
    }
    
    @IBAction func homeClicked(_ sender: Any)
    {
        // go to initial page
        self.homeAlert(warning: "Are you sure to not playing games more?")
    }
}
